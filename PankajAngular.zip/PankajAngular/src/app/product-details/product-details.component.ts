import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Products } from '../model/Products';


@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit{

  selectedProductId:number;
  @Input("selProduct") product: Products | null;


  constructor(private route:ActivatedRoute){
    this.selectedProductId=-1;
    this.product=null;
  }
  ngOnInit() {
    if (this.route.snapshot.paramMap.has("productId")) {
      this.selectedProductId = parseInt(this.route.snapshot.paramMap.get("productId") ?? "-1");
  }else{
    this.selectedProductId=-1;
  }
 console.log(this.product,'prodcut');

  }
}
