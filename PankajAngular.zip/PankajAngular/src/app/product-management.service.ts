import { Injectable } from '@angular/core';
import { Products } from './model/Products';

@Injectable()
export class ProductManagementService {
  productsArr: Products[];
  constructor() {
    this.productsArr = [
      new Products(102,"Iphone 16","../assets/iphone16.jpg",75000,10),
      new Products(101,"Iphone 12","../assets/iphone12.jpg",40000,30),
      new Products(103,"Iphone 15","../assets/iphone15.jpg",65000,20),
      new Products(104,"Poco F5","../assets/pocoF5.jpg",20000,5),
      new Products(105,"Vivo Y20","../assets/vivoy20.jpg",14000,45)

   ];
  }
  addProductsItem(ProductsObj: Products) {
    this.productsArr.push(ProductsObj);
    console.log(this.productsArr)
  }
  getAllProductsItems() {
    return this.productsArr;
  }
  deleteProductsItem(productId: number) {
    var pos = this.productsArr.findIndex(item => item.productId == productId);
    if (pos >= 0) {
      this.productsArr.splice(pos, 1);
      return true;
    }
    else {
      return false;
    }
  }
}