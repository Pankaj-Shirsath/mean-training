import { Component, Input } from '@angular/core';
import { Cart } from '../model/Cart';
import { Router } from '@angular/router';
import { CartManagementService } from '../cart-management.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  //@Input() cartItems:Cart[] | null;
  showCartItems:Boolean;
  totalAmount:number;

  // constructor(private router:Router, private cms:CartManagementService) {
  //   this.cartItems = [];
  //   this.showCartItems=false;
  // }

 
    cartArr: Cart[];
    constructor(private router: Router, private cms: CartManagementService) {
      this.cartArr = cms.getAllCartItems();
      this.showCartItems=false;
      this.totalAmount=0;
  
    }

  
ngOnInit(){
  console.log( this.cartArr?.length,"init",this.cartArr);
  
  if( this.cartArr?.length) {
    this.showCartItems = false;
  } else { 
    this.showCartItems = true;
  }

  this.cartArr.forEach(product => {
   let tempAmount= product.quantitySelected*product.price;
   this.totalAmount=tempAmount+this.totalAmount;
   console.log("totalAmount",this.totalAmount);
   
  });
  
}
proceedToPaymentEventHandler(){
  this.router.navigate(['/payments']);
}


}

