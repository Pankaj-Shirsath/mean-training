import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchArr'
})
export class SearchArrPipe implements PipeTransform {

  transform(value: any[], searchText: string, fieldName:string): any[] {
    if(searchText == "")
    return value;
 
    if (fieldName == "") {
      return value;
    }
    var filteredArr = value.filter(element=>  {
     
      if(element[fieldName].toString().toLowerCase().includes(searchText) ) {
        return element;
      }
    })
 
    return filteredArr;
  }
 

}
