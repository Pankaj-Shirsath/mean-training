import { Component, EventEmitter, Input , OnChanges, OnDestroy, OnInit, Output, SimpleChanges} from '@angular/core';
import { Cart, Products } from '../model/Cart';
import { CartManagementService } from '../cart-management.service';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnChanges, OnInit , OnDestroy{
  cartObj: Cart | null;
  quantitySelected:number;
  @Input() companyName:string;
  @Input("selProduct") product: Products | null;
  @Output() sendDataFromAddToCartToPD: EventEmitter< Cart| null>;
  @Output() sendCancelEventFromAddToCartToPD: EventEmitter<void>;
  
  constructor(private cartManagementService: CartManagementService){
    this.companyName="Edforce";
    this.product=null;
    this.quantitySelected=1;
    this.sendDataFromAddToCartToPD =new EventEmitter< Cart| null> ();
    this.sendCancelEventFromAddToCartToPD = new EventEmitter<void>();
    this.cartObj = null;
  
  }

  ngOnDestroy():void{
    console.log("destroy", this.cartObj)
    if(this.cartObj){
     
      alert("Items added to the cart " +this.product?.productId);
      // this.selectedProductsArr.push(this.cartObj);
      // console.log("a",this.selectedProductsArr)
    }else{
      alert("Sorry to see u go !!!!")
    }    
  }
  
  ngOnInit(): void {
   console.log("ngOnInit of Add To cart called");
    console.log("Selected Product", this.product);
     }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("onChanges  in add to cart")
    console.log("Changes", changes)
    if(changes['product'] && changes['product'].previousValue && changes['product'].currentValue.productId !== changes['product'].previousValue.productId){
      this.quantitySelected=1;
    }
    console.log("Selected Product", this.product);//mounting -- ud ; product clicked
    //contructor -- product -- null
    //ngOnInit -- product -- data from parent
    //when is the data from the parent assigned to input decorators -- after ngOnchanges ; before
    //answere : - data assignement -- onChanges
  }
  modifyQuantity(op:string){
    if(op=="dec"){
      if(this.quantitySelected > 1)
        this.quantitySelected--;
    }
    else{
      if(this.product && (this.quantitySelected < this.product.quantity)){
        this.quantitySelected++;
      }
    }
    }
   confirmEventHandler(){
      this.cartObj =this.product ? new Cart(this.product.productId,this.product.productName,this.product.imageUrl,this.product.price,this.product.quantity,this.quantitySelected):null;
      if (this.cartObj) {
        // trigger the event or emit the event
        this.sendDataFromAddToCartToPD.emit(this.cartObj);
  
        this.cartManagementService.addCartItem(this.cartObj);
      }}

    cancelEventHandler(){ 

      console.log("before cancelEventHandler");
      this.sendCancelEventFromAddToCartToPD.emit();
      console.log("after cancelEventHandler");
    }

  }
