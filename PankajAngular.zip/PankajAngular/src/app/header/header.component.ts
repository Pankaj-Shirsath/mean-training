import { Component } from '@angular/core';
 
@Component({
  selector: 'app-header',
  standalone: false,
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
 
  userId: string = 'User'; // Replace this with the actual user ID logic

  constructor() {
    // Logic to fetch or set the userId can go here
  }

}