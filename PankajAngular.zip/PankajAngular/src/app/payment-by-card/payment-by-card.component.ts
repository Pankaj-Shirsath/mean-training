import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-payment-by-card',
  templateUrl: './payment-by-card.component.html',
  styleUrls: ['./payment-by-card.component.css']
})
export class PaymentByCardComponent {
  paymentForm: FormGroup;

  constructor(private fb: FormBuilder) {
    // Initialize the form with FormBuilder
    this.paymentForm = this.fb.group({
      cardNumber: ['', [Validators.required, Validators.pattern(/^\d{4} \d{4} \d{4} \d{4}$/)]],
      expirationDate: ['', [Validators.required, Validators.pattern(/^(0[1-9]|1[0-2])\/?([0-9]{2})$/)]],
      cvv: ['', [Validators.required, Validators.pattern(/^\d{3}$/)]]
    });
  }

  onSubmit() {
    if (this.paymentForm.valid) {
      // Show success alert
      alert('Your payment has been received. Thank you!');
      console.log('Payment submitted', this.paymentForm.value);
      // Handle the payment processing logic here
      this.paymentForm.reset(); // Optionally reset the form after submission
    } else {
      console.log('Form is invalid');
    }
  }
}

