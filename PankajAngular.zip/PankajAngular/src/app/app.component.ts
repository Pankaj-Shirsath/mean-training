import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class AppComponent {
  title = 'MyFirstApp';
  companyName:string;
  fruits:string[];
  isMember:boolean;
  ctr:number;
  empObj:object;
  bDay:Date;
  imgUrl:any;

  constructor(){

    this.companyName='Marsh';
    this.fruits=['Apple, banana, Grapes'];
    this.isMember=true;
    this.ctr=100;
    this.empObj={"empName":"pankaj","empId":"368","salary":102};
    this.bDay=new Date(2000,5,11);
    this.imgUrl= "../assets/Thanks.jpg";
  }
}
