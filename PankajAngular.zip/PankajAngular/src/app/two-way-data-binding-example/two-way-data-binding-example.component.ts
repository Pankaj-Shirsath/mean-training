import { Component } from '@angular/core';
 
@Component({
  selector: 'app-two-way-data-binding-example',
  standalone: false,
  templateUrl: './two-way-data-binding-example.component.html',
  styleUrls: ['./two-way-data-binding-example.component.css']
})
export class TwoWayDataBindingExampleComponent {
  countryName: string;
  personName:string | undefined;
  fieldNameArr:string[];
  fieldName:string;
  constructor(
){
    this.countryName="India";
    this.personName="Pankaj";
    this.fieldNameArr=["productId","productName","premium","description","quantity"];
    this.fieldName=this.fieldNameArr[1];
}
 
inputEventHandler(event:any){
  console.log("value:" + event.target.value);
    this.countryName=event.target.value;
 
}
}