import { Directive } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { validatePasswordPattern } from './validatorFunctions/validatePasswordPattern';

@Directive({
  selector: '[appCheckPasswordPattern]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: CheckEmailPatternDirective, multi: true }
  ]
})
export class CheckEmailPatternDirective implements Validator {

  constructor() { }
  validate(control: AbstractControl): ValidationErrors | null {
    return validatePasswordPattern()(control);
  }


}
