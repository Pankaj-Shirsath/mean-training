import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
 
@Component({
  selector: 'app-register-model',
  templateUrl: './register-model.component.html',
  styleUrls: ['./register-model.component.css']
})

export class RegisterModelComponent implements OnInit{
  registerModelFormGroup!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.registerModelFormGroup = this.fb.group({
      fullName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$')]],
      password: ['', [Validators.required, Validators.minLength(8), this.validatePasswordPattern]],
      confirmPassword: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^(\+91)?[789]\d{9}$/)]] //  phone number pattern
    }, { validator: this.passwordMatchValidator });
 
  }
  validatePasswordPattern(control: FormControl) {
    const pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/; // At least one uppercase, one lowercase, and one number
    return pattern.test(control.value) ? null : { passwordPattern: true };
  }

  passwordMatchValidator(formGroup: FormGroup) {
    const password = formGroup.get('password')?.value;
    const confirmPassword = formGroup.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { mismatch: true };
  }

  submitEventHandler(registerFormValue: any) {
    // Show success alert
    alert('Registration successful! Welcome!');
    console.log('Form submitted:', this.registerModelFormGroup.value);

    // Reset the form after successful submission
    this.registerModelFormGroup.reset();
  }
}



 