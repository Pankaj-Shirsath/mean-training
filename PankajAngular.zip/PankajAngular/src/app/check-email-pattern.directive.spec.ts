import { CheckEmailPatternDirective } from './check-email-pattern.directive';

describe('CheckEmailPatternDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckEmailPatternDirective();
    expect(directive).toBeTruthy();
  });
});
