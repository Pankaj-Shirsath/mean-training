import { Component, EventEmitter, inject, Output } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../model/Cart';
import { Router } from '@angular/router';
import { ProductManagementService } from '../product-management.service';
 
@Component({
  selector: 'app-product-display',

  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent {
 
  isValidated:boolean;
  productsArr:Products[];
  companyName:string
  showAddToCart:boolean;
  selectedProduct:Products | null;
  @Output() sendDataFromPDToCart: EventEmitter<Cart| null>;
  productManagementService: ProductManagementService;


  //@Output() sendDataFromPDToCart!: EventEmitter<Cart | null>;


  constructor(private router:Router)
  {
    this.productManagementService= inject(ProductManagementService)
    this.isValidated=false;
    this.showAddToCart = false;
    this.companyName="Marsh";
    this.selectedProduct=null;
    this.productsArr=this.productManagementService.getAllProductsItems();;
    this.sendDataFromPDToCart =new EventEmitter< Cart| null> ();

    
  }
  addToCart(selectedProduct:Products){
    this.selectedProduct=selectedProduct;
    console.log(this.selectedProduct,'inside addtocart');

    this.showAddToCart = true;
    this.isValidated=true;
    // alert("Value of isValidated " + this.isValidated);
    //alert("Button clicked " + selectedProduct.productName);
  }
  changeCompanyName() {
    this.companyName = "Apple";
  }
  sendDataFromAddToCartToPDEventHandler(cartObj: Cart | null) {

    console.log("inside sendDataFromAddToCartToPDEventHandler", cartObj)
    if (cartObj != null) {
      // update the quantity in productsArr
      var pos = this.productsArr.findIndex(product => product.productId == cartObj.productId);
      if (pos >= 0) {
        this.productsArr[pos].quantity = this.productsArr[pos].quantity - cartObj.quantitySelected;
      }
      console.log('before unmount', this.selectedProduct);

     //this.sendDataFromPDToCart.emit(cartObj);
      
      // unmount the child component
      this.showAddToCart = false;
      // selectedProduct -- null
      this.selectedProduct = null;

      this.sendDataFromPDToCart.emit(cartObj);

    }
  }
  sendCancelEventFromAddToCartToPDEventHandler() {
    console.log("inside sendCancelEventFromAddToCartToPDEventHandler")
    this.showAddToCart = false;
    this.selectedProduct = null;
  }
  detailsEventHandler(selectedProduct:Products){
     // navigate to productdetails component
     
    this.selectedProduct=selectedProduct;
    console.log(selectedProduct,'inside details');
    this.router.navigate(['/productDetails', selectedProduct.productId]);
  }
  
}


