import { Component } from '@angular/core';
import { Products } from '../model/Products';
import { ProductManagementService } from '../product-management.service';

@Component({
  selector: 'app-search-products',
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent {
  productsArr: Products[];
  searchText: string;
  fieldName:string;
  fieldsNameArr:string[];
  selectedProduct: Products | null;
  productManagementService: ProductManagementService = new ProductManagementService;


  constructor() {
    this.selectedProduct = null;
    this.productsArr=this.productManagementService.getAllProductsItems();;
    this.fieldsNameArr = ["productId", "productName", "price", "quantity"];
    this.searchText = "";
    this.fieldName="";
   
  }
  searchEventHandler(text: string, fieldName:string) {
    this.searchText = text;
    this.fieldName = fieldName;
  }
    editEventHandler(selectedProduct: Products) {
    this.selectedProduct = selectedProduct;
  }
}
  

